package sample.models;

public class Population {
    Route[] routes;

    // Construct a population
    public Population(int populationSize, boolean initialise) {
        routes = new Route[populationSize];
        // If we need to initialise a population of routes do so
        if (initialise) {
            // Loop and create individuals
            for (int i = 0; i < populationSize(); i++) {
                Route newRoute = new Route();
                newRoute.generateIndividual();
                saveRoute(i, newRoute);
            }
        }
    }

    // Saves a tour
    public void saveRoute(int index, Route tour) {
        routes[index] = tour;
    }

    // Gets a tour from population
    public Route getRoute(int index) {
        return routes[index];
    }

    // Gets the best tour in the population
    public Route getFittest() {
        Route fittest = routes[0];
        // Loop through individuals to find fittest
        for (int i = 1; i < populationSize(); i++) {
            if (fittest.getFitness() <= getRoute(i).getFitness()) {
                fittest = getRoute(i);
            }
        }
        return fittest;
    }

    // Gets population size
    public int populationSize() {
        return routes.length;
    }
}
