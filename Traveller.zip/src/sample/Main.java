package sample;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.control.TextField;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Polygon;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import sample.models.City;
import sample.models.Population;
import sample.models.RouteManager;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;


public class Main extends Application {
    Scene scene;
    boolean useFile = false;

    @Override
    public void start(Stage primaryStage) throws Exception {

        primaryStage.setTitle("Travelling Salesman Simulation");

        HBox hBox = new HBox(10);
        VBox vbIngredients = new VBox(10);
        VBox vbRecipe = new VBox(10);

        hBox.setPadding(new Insets(20));

        Pane simulationPanel = new Pane();
        simulationPanel.setPadding(new Insets(10));
        simulationPanel.setBackground(new Background(new BackgroundFill(Color.GREY, null, null)));

        Label searchLabel = new Label("No Simulations yet!");

//Scene 1
        Label ingLabel = new Label("Settings:");
        Label citiesLabel = new Label("Number of cities:");
        TextField numCities = new TextField();

        Label iterations = new Label("Number of iteration:");
        TextField numIterations = new TextField();
        Button btnRun = new Button("Run Simulation");
        Separator separator = new Separator();


        Button btnReadFromFile = new Button("Read Cities From file");

        btnReadFromFile.setOnAction(e -> {
            simulationPanel.getChildren().clear();
            FileChooser fileChooser = new FileChooser();
            fileChooser.getExtensionFilters().addAll(
                    new FileChooser.ExtensionFilter("Text Files", "*.txt")
            );
            File selectedFile = fileChooser.showOpenDialog(primaryStage);

            try {
                FileReader fr = new FileReader(selectedFile);   //reads the file
                BufferedReader br = new BufferedReader(fr);
                String line;
                while ((line = br.readLine()) != null) {
                    String[] cityData = line.split(",");
                    City city = new City(Integer.parseInt(cityData[0]), Integer.parseInt(cityData[1]));
                    Label cityLabel = new Label("(" + city.getX() + "," + city.getY() + ")");
                    cityLabel.setTranslateX(city.getX());
                    cityLabel.setTranslateY(city.getY());
                    simulationPanel.getChildren().add(cityLabel);
                    RouteManager.addCity(city);
                }
                fr.close();
            } catch (Exception exc) {
                exc.printStackTrace();
            }

            int pop = 100;

            Population population = new Population(pop, true);

            population = Solution.evolvePopulation(population);
            for (int i = 0; i < pop; i++) {
                population = Solution.evolvePopulation(population);
            }

            Polygon polygon = new Polygon();
            polygon.getPoints().addAll(population.getFittest().coordinates());
            polygon.setStroke(Color.BLUE);
            polygon.setStrokeWidth(2);
            polygon.setFill(Color.TRANSPARENT);


            simulationPanel.getChildren().addAll(polygon);

            searchLabel.setText("Distance: " + population.getFittest().getDistance());
            RouteManager.reset();

        });

        btnRun.setOnAction(e -> {
            //reset panel
            simulationPanel.getChildren().clear();
            int cities = Integer.parseInt(numCities.getText());
            int pop = Integer.parseInt(numIterations.getText());

            for (int i = 0; i < cities; i++) {
                City city = new City();
                Label cityLabel = new Label("(" + city.getX() + "," + city.getY() + ")");
                cityLabel.setTranslateX(city.getX());
                cityLabel.setTranslateY(city.getY());
                simulationPanel.getChildren().add(cityLabel);
                RouteManager.addCity(city);
            }

            Population population = new Population(pop, true);

            population = Solution.evolvePopulation(population);
            for (int i = 0; i < pop; i++) {
                population = Solution.evolvePopulation(population);
            }

            Polygon polygon = new Polygon();
            polygon.getPoints().addAll(population.getFittest().coordinates());
            polygon.setStroke(Color.BLUE);
            polygon.setStrokeWidth(2);
            polygon.setFill(Color.TRANSPARENT);


            simulationPanel.getChildren().addAll(polygon);

            searchLabel.setText("Distance: " + population.getFittest().getDistance());
            RouteManager.reset();

        });
        numIterations.setPrefWidth(250);
        VBox.setVgrow(numIterations, Priority.ALWAYS);

        vbIngredients.getChildren().addAll(ingLabel, citiesLabel, numCities, iterations, numIterations, btnRun, separator, btnReadFromFile);

        Label recipeLabel = new Label("Current Simulation");
        simulationPanel.setMinWidth(500);

        vbRecipe.getChildren().addAll(recipeLabel, simulationPanel, searchLabel);
        VBox.setVgrow(simulationPanel, Priority.ALWAYS);

        hBox.getChildren().addAll(vbIngredients, vbRecipe);

        scene = new Scene(hBox, 700, 600);


        primaryStage.setScene(scene);
        primaryStage.show();
    }


    public static void main(String[] args) {
        launch(args);
    }
}
